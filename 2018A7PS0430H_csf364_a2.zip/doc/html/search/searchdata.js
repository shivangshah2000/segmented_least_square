var indexSectionsWithContent =
{
  0: "s",
  1: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

