var searchData=
[
  ['segmented_20least_20squares_0',['Segmented Least Squares',['../index.html',1,'']]]
];
