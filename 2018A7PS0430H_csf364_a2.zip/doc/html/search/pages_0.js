var searchData=
[
  ['segmented_20least_20squares_1',['Segmented Least Squares',['../index.html',1,'']]]
];
